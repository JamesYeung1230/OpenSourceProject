export default {
  counter: 2,
  isPhone: false
}
