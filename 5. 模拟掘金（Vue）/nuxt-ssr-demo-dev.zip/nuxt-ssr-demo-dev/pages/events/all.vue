<template>
  <div class="events-page">
    活动页面
  </div>
</template>

<script>
export default {
  head () {
    return {
      title: '小册',
      meta: [
        { hid: 'events custom title', name: 'events', content: 'events custom title description' }
      ]
    }
  }
}
</script>

<style lang="stylus" scoped>
.events-page {
  font-size 20px
  margin-top 1.767rem
  text-align center
}
</style>
