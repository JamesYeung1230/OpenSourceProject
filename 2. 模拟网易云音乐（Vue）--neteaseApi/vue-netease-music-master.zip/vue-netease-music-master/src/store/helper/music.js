import { createNamespacedHelpers } from 'vuex'

export const { mapState, mapMutations, mapGetters, mapActions } = createNamespacedHelpers('music')