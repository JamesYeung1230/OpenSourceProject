export default {
  // 登录用户
  user: {},
  // 登录用户歌单
  userPlaylist: []
}
