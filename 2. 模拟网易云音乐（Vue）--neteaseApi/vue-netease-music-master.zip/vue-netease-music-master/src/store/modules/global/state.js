export default {
  axiosLoading: false,
}
