export const REPOSITORY = 'https://github.com/uniquemo/react-netease-music'
export const USER_PROFILE = 'https://github.com/uniquemo'
