export const PAGE = 1
export const PAGE_SIZE = 100
export const TOTAL = 0
