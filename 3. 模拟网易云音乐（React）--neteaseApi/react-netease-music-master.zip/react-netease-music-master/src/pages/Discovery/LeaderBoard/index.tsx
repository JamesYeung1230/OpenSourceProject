import React from 'react'

const LeaderBoard = () => {
  return <div>LeaderBoard</div>
}

export default LeaderBoard
