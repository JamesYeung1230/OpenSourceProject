import React from 'react'

const Singers = () => {
  return <div>Singers</div>
}

export default Singers
