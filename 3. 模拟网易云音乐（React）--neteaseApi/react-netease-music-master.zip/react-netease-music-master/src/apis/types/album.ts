import { IAlbum } from './business'

export interface IGetAlbumResponse {
  album: IAlbum
  songs: any[]
}
