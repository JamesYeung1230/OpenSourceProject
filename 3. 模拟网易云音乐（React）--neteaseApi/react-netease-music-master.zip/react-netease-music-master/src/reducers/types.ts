export interface IAction {
  type: string
  payload?: IDictionary<any>
}
