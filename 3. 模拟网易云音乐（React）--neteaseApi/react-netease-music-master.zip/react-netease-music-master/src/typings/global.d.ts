interface IDictionary<T> {
  [key: string]: T
}

declare let __LOCALHOST__: string
