import createHTMLMediaHook from './utils/createHTMLMediaHook'

const useAudio = createHTMLMediaHook('audio')

export default useAudio
