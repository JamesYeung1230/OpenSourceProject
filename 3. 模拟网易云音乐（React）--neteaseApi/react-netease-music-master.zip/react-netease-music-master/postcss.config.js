module.exports = {
  // parser: 'sugarss',   // 若使用sugarss解析器，会报错说不能使用大括号
  plugins: {
    'postcss-nested': {}
  }
}
