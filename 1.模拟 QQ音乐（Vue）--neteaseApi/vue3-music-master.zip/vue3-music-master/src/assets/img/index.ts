import Logo from './logo.png'
import OpticalDisk from './OpticalDisk.png'

export {
    Logo,
    OpticalDisk
}
