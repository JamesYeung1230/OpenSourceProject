<template>
  <div>
    <Banner/>
    <Video/>
    <DjProgram/>
    <Mv/>
  </div>
</template>

<script setup lang="ts">
import Banner from "@/components/common/Banner.vue";
import Video from "./Video.vue";
import Mv from "@/views/discover/Mv.vue";
import DjProgram from "@/views/discover/DjProgram.vue";
</script>


<style lang="scss">

</style>
