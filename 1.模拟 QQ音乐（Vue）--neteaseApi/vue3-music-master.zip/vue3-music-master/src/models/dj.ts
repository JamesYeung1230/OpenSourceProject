export interface DJBanner {
	targetId: number;
	targetType: number;
	pic: string;
	url: string;
	typeTitle: string;
	exclusive: boolean;
}
