import{_ as r}from"./plugin-vue_export-helper.21dcd24c.js";const e={};function _(c,n){return null}var a=r(e,[["render",_]]);export{a as default};
