<template>
    <div id="settings">
        settings
        <br>
        <router-link to="/self/settings/common">通用</router-link>
    </div>
</template>
<script>
    export default {}
</script>
<style lang="less">
    @import "../../assets/less/settings.less";
</style>