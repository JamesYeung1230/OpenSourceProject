const OfficialAccounts = [{
    wxid: "Google_Developers",
    name: "谷歌开发者",
    headerUrl: "/images/OfficialAccount/google-dev.JPG",
    desc: "",
    owner: "谷歌信息技术有限公司",
    initial: "G"
}, {
    wxid: "overwatch163",
    name: "守望先锋",
    desc: "",
    headerUrl: "/images/OfficialAccount/overwatch.JPG",
    owner: "上海网易公司",
    initial: "O"
}, {
    wxid: "FrontDev",
    name: "前端大全",
    desc: "",
    headerUrl: "/images/OfficialAccount/frontend.JPG",
    owner: "",
    initial: "Q"
}, {
    wxid: "xituarea",
    name: "稀土区",
    desc: "",
    headerUrl: "/images/OfficialAccount/xitu.JPG",
    owner: "个人",
    initial: "X"
}, {
    wxid: "LOL-922",
    name: "英雄联盟",
    desc: "",
    headerUrl: "/images/OfficialAccount/lol.JPG",
    owner: "腾讯技术有限公司",
    initial: "Y"
}]
export default OfficialAccounts