module.exports = {
    publicPath: './'
}